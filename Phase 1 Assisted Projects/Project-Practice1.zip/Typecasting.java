package practice;

public class Typecasting {
	public static void main(String[] args) {
	//implicit Type
	byte b=20;
	short s=b;
	int i=s;
	long l=i;
	float f=l;
	double d=f;//implicit Type
	System.out.println("Byte:" + b);
    System.out.println("Short:" + s);
    System.out.println("int:" + i);
    System.out.println("long:" + l);
    System.out.println("float:" + f);
    System.out.println("double:" + d);
	//explicit Type
    int a=(int)100.1;
    double c=(double)10;
	System.out.println("integer "+a);
	System.out.println("double:" + c);
}


}

	


