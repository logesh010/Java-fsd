package practice;


public class Constructor {
	public Constructor()
	{
		System.out.println("Default Constructor");
	}
	public Constructor(int a)
	{
		System.out.println("parameteraized constructor with int: " + a);
		
	}
	public Constructor(String s, float b)
	{
		System.out.println("parameteraized constructor with string and int: " + s + " "+ b);
	}
	

	public static void main(String[] args) {
		Constructor Constructor = new Constructor();
		Constructor Constructor1 = new Constructor(7);
		Constructor Constructor2 = new Constructor("Hello ", 60);
		

	}

}