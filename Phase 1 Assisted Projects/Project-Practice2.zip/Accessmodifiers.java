package practice;

public class Accessmodifiers {
	//Public
		public static void a() {
			System.out.println("public modifier ");
		}
		//protected
		protected static void b() {
			System.out.println("protected modifier ");
		}
		//private
		private static void c() {
			System.out.println("private modifier");
		}
		//default
		static void d() {
			System.out.println("default access modifer");
		}
		public static void main(String[] args){
			Accessmodifiers.a();
			Accessmodifiers.b();
			Accessmodifiers.c();
			Accessmodifiers.d();
		  
			}
}

