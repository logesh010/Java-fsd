package practice3;

interface A{
	default void sun() {

		System.out.println("I am Logesh");
	}
}


interface B{
	default void sun() {

		System.out.println("Employee of mphasis");

	}
}

class C implements A,B{
	public void sun() {
		A.super.sun();
	}

}

public class Diamond {

	public static void main(String[] args) {

		C obj=new C();
		obj.sun();
	}

}

