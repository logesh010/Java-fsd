package practice1;

public class Array {
	public static void main(String[] args) {
		int[]numbers= {10,20,30,40,50};
		System.out.println("Elements of Array");
		for(int i=0;i<numbers.length;i++) {
			System.out.println(numbers[i]);
		}
		int sum=0;
		for(int n : numbers) {
			sum=sum+n;
		}
		System.out.println(sum);
		numbers[2]=6;
		System.out.println(numbers[2]);
	}
}


