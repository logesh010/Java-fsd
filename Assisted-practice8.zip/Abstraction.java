package practice3;

public class Abstraction {
	CalcImp calimpl=new CalcImp();
	calimpl.ub(23,34);

}
