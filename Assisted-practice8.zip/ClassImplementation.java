package practice3;

public class ClassImplementation {
	
	public static void main(String[] args) {
		
		System.out.println(" Class ClassImplemetation is class");
	}

}
