package practice1;

public class TryAndCatch {

		public static void main(String[] args) {
			

			try {
				int num=90;
				int divide=num/0;
				
				System.out.println("Result is:"+divide);
			}
			
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			
			System.out.println(" No Exception");
		}

	}

